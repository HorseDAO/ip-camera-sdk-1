package main.java.com.netdevsdk.demo.alarm;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JOptionPane;

import com.sun.jna.Memory;
import com.sun.jna.Pointer;

import main.java.com.netdevsdk.demo.NetDemo;
import main.java.com.netdevsdk.demo.util.Common;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_ALARM_RELATED_DATA_S;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_LAPI_SUB_INFO_S;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_NON_MOTOR_VEH_INFO_S;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_PERSON_ATTR_S;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_PERSON_STRUCT_INFO_S;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_STRUCT_IMAGE_INFO_S;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_SUBSCRIBE_SUCC_INFO_S;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_VEH_INFO_S;

/**
 * @description This section includes subscribing alarm,closing subscribe alarm and clearing alarm.
 * @introduction Support IPC/NVR/VMS.
 */
public class Alarm {
    /**
     * @description To subscribe alarm.
     * @introduction Calling the interface of NETDEV_SetAlarmCallBack_V30.
     */
    public static void SubscribeAlarm() {
        if(null == NetDemo.lpUserID)
        {
            JOptionPane.showMessageDialog(null, "Please Login device first. error code"+NetDemo.netdevsdk.NETDEV_GetLastError());
            return;
        }

        //IPC��nvr�赥������15,bit13(8192)����ע��V40�ص���ͼƬ�ص�
        if(NetDemo.jComboBoxDeviceType.getSelectedIndex() == 0) {
        	//ע��澯�ص�
            boolean bRet = NetDemo.netdevsdk.NETDEV_SetAlarmCallBack_V40(NetDemo.lpUserID, NetDemo.cbAlarmMessCallBackV40, null);
            if(false == bRet) {
                System.out.printf("NETDEV_SetAlarmCallBack_V40 failed,error code"+ NetDemo.netdevsdk.NETDEV_GetLastError());
            }
            else{
            	System.out.printf("NETDEV_SetAlarmCallBack_V40 success");
            }
        	//ע��ͼƬ�ص�
            bRet = NetDemo.netdevsdk.NETDEV_SetPicAlarmCallBack(NetDemo.lpUserID, NetDemo.cbPicMessCallBack, NetDemo.lpUserID);
            if(false == bRet) {
                System.out.printf("NETDEV_SetPicAlarmCallBack failed,error code"+ NetDemo.netdevsdk.NETDEV_GetLastError());
            }
            else{
            	System.out.printf("NETDEV_SetPicAlarmCallBack success");
            }
            
            //���ĸ澯
            NETDEV_LAPI_SUB_INFO_S stSubInfo = new NETDEV_LAPI_SUB_INFO_S();
            stSubInfo.udwType = 15;
            NETDEV_SUBSCRIBE_SUCC_INFO_S stSubSuccInfo = new NETDEV_SUBSCRIBE_SUCC_INFO_S();
            bRet = NetDemo.netdevsdk.NETDEV_SubscibeLapiAlarm(NetDemo.lpUserID, stSubInfo, stSubSuccInfo);
            if(false == bRet){
                System.out.printf("NETDEV_SubscibeLapiAlarm failed:%d\n", NetDemo.netdevsdk.NETDEV_GetLastError());
                //JOptionPane.showMessageDialog(null, "NETDEV_SubscibeLapiAlarm 15 failed");
                return;
            }
            else{
            	NetDemo.udwAlarmSubID = stSubSuccInfo.udwID;
                System.out.printf("NETDEV_SubscibeLapiAlarm 15 succ\n");
            	//JOptionPane.showMessageDialog(null, "NETDEV_SubscibeLapiAlarm 15 success");
            }
            //����ͼƬ
            stSubInfo.udwType = 8192;
            bRet = NetDemo.netdevsdk.NETDEV_SubscibeLapiAlarm(NetDemo.lpUserID, stSubInfo, stSubSuccInfo);
            if(false == bRet){
                System.out.printf("NETDEV_SubscibeLapiAlarm failed:%d\n", NetDemo.netdevsdk.NETDEV_GetLastError());
                //JOptionPane.showMessageDialog(null, "NETDEV_SubscibeLapiAlarm bit13 failed");
                return;
            }
            else{
            	NetDemo.udwPicSubID = stSubSuccInfo.udwID;
                System.out.printf("NETDEV_SubscibeLapiAlarm bit13 succ\n");
            	//JOptionPane.showMessageDialog(null, "NETDEV_SubscibeLapiAlarm bit13 success");
            }
        }
        
        //vms�� NETDEV_SetAlarmCallBack_V30 �ڲ�����
        boolean bRet = NetDemo.netdevsdk.NETDEV_SetAlarmCallBack_V30(NetDemo.lpUserID, NetDemo.cbAlarmMessCallBack, null);
        if(bRet) {
            JOptionPane.showMessageDialog(null, "Subscribe success");
        }else {
            JOptionPane.showMessageDialog(null, "NETDEV_SetAlarmCallBack_V30 failed,error code"+ NetDemo.netdevsdk.NETDEV_GetLastError());
        }
    }
    /**
     * @description To close subscribe alarm.
     * @introduction Calling the interface of NETDEV_SetAlarmCallBack_V30.
     */
    public static void UnSubscribeAlarm() {
        if(null == NetDemo.lpUserID)
        {
            JOptionPane.showMessageDialog(null, "Please Login device first. error code"+NetDemo.netdevsdk.NETDEV_GetLastError());
            return;
        }
        
        //IPC��nvr�赥������15����ע��V40�ص�
        if(NetDemo.jComboBoxDeviceType.getSelectedIndex() == 0) {
        	//ȡ���澯�ص�
            boolean bRet = NetDemo.netdevsdk.NETDEV_SetAlarmCallBack_V40(NetDemo.lpUserID, null, null);
            if(false == bRet) {
                System.out.printf("NETDEV_SetAlarmCallBack_V40 failed,error code"+ NetDemo.netdevsdk.NETDEV_GetLastError());
            }
            else{
            	System.out.printf("NETDEV_SetAlarmCallBack_V40 success");
            }
        	//ȡ��ͼƬ�ص�
            bRet = NetDemo.netdevsdk.NETDEV_SetPicAlarmCallBack(NetDemo.lpUserID, null, NetDemo.lpUserID);
            if(false == bRet) {
                System.out.printf("NETDEV_SetPicAlarmCallBack failed,error code"+ NetDemo.netdevsdk.NETDEV_GetLastError());
            }
            else{
            	System.out.printf("NETDEV_SetPicAlarmCallBack success");
            }
            //ȡ���澯����
            bRet = NetDemo.netdevsdk.NETDEV_UnSubLapiAlarm(NetDemo.lpUserID, NetDemo.udwAlarmSubID);
            if(false == bRet){
                System.out.printf("NETDEV_SubscibeLapiAlarm failed:%d\n", NetDemo.netdevsdk.NETDEV_GetLastError());
                //JOptionPane.showMessageDialog(null, "NETDEV_UnSubLapiAlarm failed");
            }
            else{
            	System.out.printf("NETDEV_UnSubLapiAlarm 15 success");
            	//JOptionPane.showMessageDialog(null, "NETDEV_UnSubLapiAlarm success");
            }
            //ȡ��ͼƬ����
            bRet = NetDemo.netdevsdk.NETDEV_UnSubLapiAlarm(NetDemo.lpUserID, NetDemo.udwPicSubID);
            if(false == bRet){
                System.out.printf("NETDEV_SubscibeLapiAlarm failed:%d\n", NetDemo.netdevsdk.NETDEV_GetLastError());
                //JOptionPane.showMessageDialog(null, "NETDEV_UnSubLapiAlarm failed");
            }
            else{
            	System.out.printf("NETDEV_UnSubLapiAlarm bit13 success");
            	//JOptionPane.showMessageDialog(null, "NETDEV_UnSubLapiAlarm success");
            }
        }

        boolean bRet = NetDemo.netdevsdk.NETDEV_SetAlarmCallBack_V30(NetDemo.lpUserID, null, null);
        if(bRet==false) {
            JOptionPane.showMessageDialog(null, "NETDEV_SetAlarmCallBack_V30 failed,error code"+ NetDemo.netdevsdk.NETDEV_GetLastError());
            return;
        }else {
            JOptionPane.showMessageDialog(null, "UnSubscribe success");
        }
    }
    /**
     * @description To clear alarm.
     */
    public static void ClearAlarm() {
        NetDemo.AlarmTableModel.setRowCount(0);
    }
    
    /**
     * @description Get the related data of the selected alarm in alarm table
     * support fall_object_detection
     */
    public static void getRelatedData() {
        if(null == NetDemo.lpUserID) {
            JOptionPane.showMessageDialog(null, "Please Login device first.");
            return;
            }
        if(NetDemo.SubAlarmID == -1) {
            JOptionPane.showMessageDialog(null, "Please select an AlarmID.");
            return;
            }
        
        Pointer lpFindHandle = NetDemo.netdevsdk.NETDEV_FindAlarmRelatedDataList(NetDemo.lpUserID,NetDemo.SubAlarmID);
        if(null == lpFindHandle) {
            System.out.printf("NETDEV_FindAlarmRelatedDataList failed: "+ NetDemo.netdevsdk.NETDEV_GetLastError());
            return;
            }
        
        NETDEV_ALARM_RELATED_DATA_S pstAlarmRelatedData = new NETDEV_ALARM_RELATED_DATA_S();
        
        pstAlarmRelatedData.stStructDataInfo.udwImageNum = 2;
        NETDEV_STRUCT_IMAGE_INFO_S[] pstImageInfo = new NETDEV_STRUCT_IMAGE_INFO_S[pstAlarmRelatedData.stStructDataInfo.udwImageNum];
        for(int j = 0; j < pstAlarmRelatedData.stStructDataInfo.udwImageNum; j++) {
            pstImageInfo[j] = new NETDEV_STRUCT_IMAGE_INFO_S();
            pstImageInfo[j].udwSize = Common.NETDEMO_PICTURE_SIZE;
            pstImageInfo[j].pszData = new Memory(Common.NETDEMO_PICTURE_SIZE);
            }
        pstAlarmRelatedData.stStructDataInfo.pstImageInfo= new Memory(pstImageInfo[0].size()*pstAlarmRelatedData.stStructDataInfo.udwImageNum);
        Common.SetStructArrToPointerData(pstImageInfo, pstAlarmRelatedData.stStructDataInfo.pstImageInfo);
        pstAlarmRelatedData.write();
                
        boolean bRet = NetDemo.netdevsdk.NETDEV_FindNextAlarmRelatedDataInfo(lpFindHandle, pstAlarmRelatedData);
        if(bRet != true) {
            System.out.printf("NETDEV_FindNextAlarmRelatedDataInfo failed: "+NetDemo.netdevsdk.NETDEV_GetLastError());
            return;
            }else {
                pstAlarmRelatedData.read();
                //pstImageInfo =  Common.pointerToStructureArray(pstAlarmRelatedData.stStructDataInfo.udwImageNum,pstAlarmRelatedData.stStructDataInfo.pstImageInfo, NETDEV_STRUCT_IMAGE_INFO_S.class);        
                Common.GetPointerDataToStructArr(pstAlarmRelatedData.stStructDataInfo.pstImageInfo, pstImageInfo);
                if(0 < pstAlarmRelatedData.stStructDataInfo.udwImageNum) {
                    //ͼƬ��Ϣ
                    for(int j = 0; j < pstAlarmRelatedData.stStructDataInfo.udwImageNum; j++ ) {
                        String curTime = Common.getDate();
                        String strImageName = NetDemo.strPicturePath  + "RelatedAlarmPic_" +  NetDemo.SubAlarmID + "_" + curTime +"_"+ j+".jpg";
                        if(0 != pstImageInfo[j].udwSize) {
                            Common.savePicture(pstImageInfo[j].pszData, pstImageInfo[j].udwSize, strImageName); 
                            JOptionPane.showMessageDialog(null, "The " + (j+1) + " picture was saved successfully");
                            }else {
                                JOptionPane.showMessageDialog(null, "The Size of the "+ (j+1) + " picture is 0");
                                }
                        }                      
                    }else {
                        JOptionPane.showMessageDialog(null, "Image Num is 0");
                        }
                }    
        bRet = NetDemo.netdevsdk.NETDEV_FindCloseAlarmRelatedDataList(lpFindHandle);
        if(bRet != true) {
            System.out.printf("NETDEV_FindCloseAlarmRelatedDataList failed: "+NetDemo.netdevsdk.NETDEV_GetLastError());
            return;
            }
        } 
    }