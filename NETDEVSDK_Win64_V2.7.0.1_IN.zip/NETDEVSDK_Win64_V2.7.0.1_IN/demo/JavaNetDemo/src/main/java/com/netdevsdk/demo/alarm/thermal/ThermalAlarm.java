package main.java.com.netdevsdk.demo.alarm.thermal;

import javax.swing.JOptionPane;

import main.java.com.netdevsdk.demo.NetDemo;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_LAPI_SUB_INFO_S;

import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_SUBSCRIBE_SUCC_INFO_S;

/**
 * @description ThermalAlarm
 * @introduction Support IPC/VMS-AIBox
 */
public class ThermalAlarm {
    public static void subscibeAlarm() {
        if(null == NetDemo.lpUserID){
            JOptionPane.showMessageDialog(null, "Please Login device first.");
            return;
        }
        
        if(-1 != NetDemo.udwThermalAlarmSubID)
        {
            JOptionPane.showMessageDialog(null, "Please UnSubLapiAlarm first.");
            return;
        }
        
        setAlarmCallBack();
        
         NETDEV_LAPI_SUB_INFO_S stSubInfo = new NETDEV_LAPI_SUB_INFO_S();
         //stSubInfo.udwType  = 12288; //bit12||bit13 
         //stSubInfo.udwType  = 4096; //bit12
         stSubInfo.udwType  = 8192; //bit13 
         NETDEV_SUBSCRIBE_SUCC_INFO_S stSubSuccInfo = new NETDEV_SUBSCRIBE_SUCC_INFO_S();
         
         boolean bRet = NetDemo.netdevsdk.NETDEV_SubscibeLapiAlarm(NetDemo.lpUserID, stSubInfo, stSubSuccInfo);
         if(false == bRet){
             System.out.printf("NETDEV_SubscibeLapiAlarm failed:%d\n", NetDemo.netdevsdk.NETDEV_GetLastError());
             JOptionPane.showMessageDialog(null, "NETDEV_SubscibeLapiAlarm failed");
             return;
             }
         else{
             NetDemo.udwThermalAlarmSubID = stSubSuccInfo.udwID;
             JOptionPane.showMessageDialog(null, "NETDEV_SubscibeLapiAlarm success");
             }
         }

    public static void unSubscibeAlarm() {
        if(null == NetDemo.lpUserID){
            JOptionPane.showMessageDialog(null, "Please Login device first.");
            return;
        }
        
        boolean bRet = NetDemo.netdevsdk.NETDEV_UnSubLapiAlarm(NetDemo.lpUserID, NetDemo.udwThermalAlarmSubID);
        if(false == bRet){
            System.out.printf("NETDEV_UnSubLapiAlarm failed:%d\n", NetDemo.netdevsdk.NETDEV_GetLastError());
            JOptionPane.showMessageDialog(null, "NETDEV_UnSubLapiAlarm failed");
            return;
        }
        else
        {
            NetDemo.udwThermalAlarmSubID = -1;
            NetDemo.jComboBoxConflagration.removeAllItems();
            NetDemo.jComboBoxSmoking.removeAllItems();
            NetDemo.jTextFiledValueType.setText(null);
            NetDemo.jTextFiledAlarmValue.setText(null);
            JOptionPane.showMessageDialog(null, "NETDEV_UnSubLapiAlarm success");
            return;
        }
    }

    private static void setAlarmCallBack() {
        boolean bRet = NetDemo.netdevsdk.NETDEV_SetConflagrationAlarmCallBackV30(NetDemo.lpUserID, NetDemo.ConflagrationAlarmMessCB_V30, null);
        boolean bRet1 = NetDemo.netdevsdk.NETDEV_SetSmokeAlarmCallBack(NetDemo.lpUserID, NetDemo.SmokingAlarmMessCB, null);
        boolean bRet2 = NetDemo.netdevsdk.NETDEV_SetTemperatureDetcCallBack(NetDemo.lpUserID, NetDemo.TemperatureAlarmMessCB, null);
        //boolean bRet3 = NetDemo.netdevsdk.NETDEV_SetConflagrationAlarmCallBack(NetDemo.lpUserID, NetDemo.ConflagrationAlarmMessCB, NetDemo.lpUserID);
        
        if(true == (bRet && bRet1 && bRet2 )) {
            JOptionPane.showMessageDialog(null, "NETDEV_SetAlarmCallBack success");
        }
        else if(false == bRet){
            System.out.printf("NETDEV_SetConflagrationAlarmCallBackV30 failed:%d\n", NetDemo.netdevsdk.NETDEV_GetLastError());
            JOptionPane.showMessageDialog(null, "NETDEV_SetConflagrationAlarmCallBackV30 failed");
            return ;
        }
        else if(false == bRet1){
            System.out.printf("NETDEV_SetSmokeAlarmCallBack failed:%d\n", NetDemo.netdevsdk.NETDEV_GetLastError());
            JOptionPane.showMessageDialog(null, "NETDEV_SetSmokeAlarmCallBack failed");
            return ;
        }
        else if(false == bRet2){
            System.out.printf("NETDEV_SetTemperatureDetcCallBack failed:%d\n", NetDemo.netdevsdk.NETDEV_GetLastError());
            JOptionPane.showMessageDialog(null, "NETDEV_SetTemperatureDetcCallBack failed");
            return ;
        }
//        else if(false == bRet3){
//            System.out.printf("NETDEV_SetConflagrationAlarmCallBack failed:%d\n", NetDemo.netdevsdk.NETDEV_GetLastError());
//            JOptionPane.showMessageDialog(null, "NETDEV_SetConflagrationAlarmCallBack failed");
//            return ;
//        }
        else {
            System.out.printf("NETDEV_SubscibeLapiAlarm failed:%d\n", NetDemo.netdevsdk.NETDEV_GetLastError());
            JOptionPane.showMessageDialog(null, "NETDEV_SubscibeLapiAlarm failed");
            return ;
        }
    }
    
}
