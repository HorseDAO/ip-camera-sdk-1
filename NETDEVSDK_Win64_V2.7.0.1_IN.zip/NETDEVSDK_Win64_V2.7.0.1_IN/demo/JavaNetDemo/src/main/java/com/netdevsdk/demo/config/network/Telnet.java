package main.java.com.netdevsdk.demo.config.network;

import javax.swing.JOptionPane;

import main.java.com.netdevsdk.demo.NetDemo;

/**
 * 
 * @introduction Telnet
 * @description Support NVR
 * 
 */
public class Telnet {

    /**
     * 
     * @introduction Open Telnet
     * @description Calling the interface of NETDEV_EnableTelnet
     *
     */
	public static void openTelnet() {
		if(null == NetDemo.lpUserID){
			JOptionPane.showMessageDialog(null, "Please Login device first. error code"+NetDemo.netdevsdk.NETDEV_GetLastError());
			return;
		}

		boolean bRet = NetDemo.netdevsdk.NETDEV_EnableTelnet(NetDemo.lpUserID, 1);
        if(bRet != true)
        {
        	JOptionPane.showMessageDialog(null, "Open failed");
        	System.out.printf("NETDEV_EnableTelnet failed:%d\n", NetDemo.netdevsdk.NETDEV_GetLastError());
            return;
        }else {
        	JOptionPane.showMessageDialog(null, "Open success");
        }
	}
	
	/**
	 * 
	 * @introduction Close telnet
	 * @description Calling the interface of NETDEV_EnableTelnet
	 *
	 */
	public static void closeTelnet() {
		if(null == NetDemo.lpUserID){
			JOptionPane.showMessageDialog(null, "Please Login device first. error code"+NetDemo.netdevsdk.NETDEV_GetLastError());
			return;
		}

		boolean bRet = NetDemo.netdevsdk.NETDEV_EnableTelnet(NetDemo.lpUserID, 0);
        if(bRet != true)
        {
        	JOptionPane.showMessageDialog(null, "Close failed,error code"+NetDemo.netdevsdk.NETDEV_GetLastError());
        	System.out.printf("NETDEV_EnableTelnet failed:%d\n", NetDemo.netdevsdk.NETDEV_GetLastError());
            return;
        }else {
        	JOptionPane.showMessageDialog(null, "Close success");
        }
	}
}
