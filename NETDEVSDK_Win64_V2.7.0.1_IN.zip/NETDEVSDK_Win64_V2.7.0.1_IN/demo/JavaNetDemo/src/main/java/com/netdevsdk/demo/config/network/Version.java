package main.java.com.netdevsdk.demo.config.network;

import main.java.com.netdevsdk.demo.NetDemo;

/**
 * 
 * @introduction Get SDK version
 * @description Support IPC/NVR/VMS
 */
public class Version {

    /**
     * 
     * @introduction Get SDK version
     * @description Calling the interface of NETDEV_GetSDKVersion
     *
     */
	public static void getSdkVersion() {
		int version=NetDemo.netdevsdk.NETDEV_GetSDKVersion();
		String getVersion=String.valueOf(version);
		String str1=getVersion.substring(0, 2);
		StringBuffer buffer=new StringBuffer();
		buffer.append(str1);
		buffer.append(".");
		String str2=getVersion.substring(2, 4);
		buffer.append(str2);
		buffer.append(".");
		String str3=getVersion.substring(4, 6);
		buffer.append(str3);
		buffer.append(".");
		String str4=getVersion.substring(6, 8);
		buffer.append(str4);
		String get=buffer.toString();
		NetDemo.jTextFieldGetSDKVersion.setText(get);
	}

}
