package main.java.com.netdevsdk.demo.maintenance;

import javax.swing.JOptionPane;

import main.java.com.netdevsdk.demo.NetDemo;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_DEVICE_TYPE_E;

/**
 * @description Find logs,find alarm and find alarm logs.
 */
public class Find {
    /**
     * @description To find logs.
     * @introduction It is mainly realized by the constructor of MaintenaceLogWindow.
     */
    public static void LogLookUp() {
        if(null == NetDemo.lpUserID)
        {
            JOptionPane.showMessageDialog(null, "Please Login device first. error code"+NetDemo.netdevsdk.NETDEV_GetLastError());
            return;
        }
        if(NetDemo.pstDeviceInfo.dwDeviceType == NETDEV_DEVICE_TYPE_E.NETDEV_DTYPE_NVR||
            NetDemo. pstDeviceInfo.dwDeviceType == NETDEV_DEVICE_TYPE_E.NETDEV_DTYPE_HNVR||
                NetDemo.pstDeviceInfo.dwDeviceType == NETDEV_DEVICE_TYPE_E.NETDEV_DTYPE_NVR_BACKUP
            )
        {
            MaintenaceLogWindow m1=new MaintenaceLogWindow(0,NetDemo.lpUserID,NetDemo.ChannelID);
            m1.setVisible(true);
        }
        else if(NetDemo.pstDeviceInfo.dwDeviceType == NETDEV_DEVICE_TYPE_E.NETDEV_DTYPE_VMS) 
        {
            MaintenaceLogWindow m2=new MaintenaceLogWindow(1,NetDemo.lpUserID,NetDemo.ChannelID);
            m2.setVisible(true);
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Not support IPC");
            return;
        }
    }
    /**
     * @description To find alarm.
     * @introduction It is mainly realized by the constructor of MaintenaceAlarmSearchWindow.
     */
    public static void AlarmLookUp() {
        if(null == NetDemo.lpUserID)
        {
            JOptionPane.showMessageDialog(null, "Please Login device first. error code"+NetDemo.netdevsdk.NETDEV_GetLastError());
            return;
        }
        if(NetDemo.pstDeviceInfo.dwDeviceType == NETDEV_DEVICE_TYPE_E.NETDEV_DTYPE_IPC ||
            NetDemo.pstDeviceInfo.dwDeviceType == NETDEV_DEVICE_TYPE_E.NETDEV_DTYPE_IPC_FISHEYE ||
                NetDemo.pstDeviceInfo.dwDeviceType == NETDEV_DEVICE_TYPE_E.NETDEV_DTYPE_IPC_ECONOMIC_FISHEYE ||
                    NetDemo.pstDeviceInfo.dwDeviceType == NETDEV_DEVICE_TYPE_E.NETDEV_DTYPE_IPC_ACS
            )
        {
            MaintenaceAlarmSearchWindow m=new MaintenaceAlarmSearchWindow(NetDemo.lpUserID,NetDemo.ChannelID);
            m.setVisible(true);
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Only support IPC equipment.");
        }
        if(NetDemo.ChannelID == 0)
        {
            JOptionPane.showMessageDialog(null, "Please Select ChannelID.");
            return;
        }
    }
    /**
     * @description To find alarm logs.
     * @introduction It is mainly realized by the constructor of MaintenaceAlarmLogWindow.
     */
    public static void AlarmLogLookUp() {
        if(null == NetDemo.lpUserID)
        {
            JOptionPane.showMessageDialog(null, "Please Login device first. error code"+NetDemo.netdevsdk.NETDEV_GetLastError());
            return;
        }
        if(NetDemo.jComboBoxDeviceType.getSelectedIndex() == 1)
        {
            MaintenaceAlarmLogWindow m3=new MaintenaceAlarmLogWindow(NetDemo.lpUserID,NetDemo.ChannelID);
            m3.setVisible(true);
        }
        else if(NetDemo.jComboBoxDeviceType.getSelectedIndex() == 0)
        {
            JOptionPane.showMessageDialog(null, "Only support VMS equipment.");
        }
    }
}
