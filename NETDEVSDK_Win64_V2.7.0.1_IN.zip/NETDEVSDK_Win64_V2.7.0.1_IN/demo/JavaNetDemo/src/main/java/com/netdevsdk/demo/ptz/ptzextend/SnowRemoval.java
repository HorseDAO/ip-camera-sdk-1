package main.java.com.netdevsdk.demo.ptz.ptzextend;

import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_PTZ_E;
/**
 * 
 * @description Snow removal operation includes opening snow removing and closing snow removing
 *
 */
public class SnowRemoval {
    
    /* Open the snow removing */
    public static void snowRemoveOn() {
        ExtendOperation.Operation(NETDEV_PTZ_E.NETDEV_PTZ_SNOWREMOINGON);
    }
    
    /* Close the snow removing */
    public static void snowRemoveOff() {
        ExtendOperation.Operation(NETDEV_PTZ_E.NETDEV_PTZ_SNOWREMOINGOFF);
    }
}
