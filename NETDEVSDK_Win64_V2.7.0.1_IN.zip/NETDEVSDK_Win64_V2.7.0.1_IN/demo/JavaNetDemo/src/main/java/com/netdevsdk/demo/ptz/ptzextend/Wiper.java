package main.java.com.netdevsdk.demo.ptz.ptzextend;

import javax.swing.JOptionPane;

import main.java.com.netdevsdk.demo.NetDemo;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_PTZ_E;
/**
 * 
 * @description Wiper operation includes opening wiper and closing wiper
 *
 */
public class Wiper {
    
    /* Open the wiper */
    public static void WiperOn() {
      ExtendOperation.Operation(NETDEV_PTZ_E.NETDEV_PTZ_BRUSHON);
    }
    
    /* Close the wiper */
    public static void WiperOff() {
      ExtendOperation.Operation(NETDEV_PTZ_E.NETDEV_PTZ_BRUSHOFF);
    }
    
}
