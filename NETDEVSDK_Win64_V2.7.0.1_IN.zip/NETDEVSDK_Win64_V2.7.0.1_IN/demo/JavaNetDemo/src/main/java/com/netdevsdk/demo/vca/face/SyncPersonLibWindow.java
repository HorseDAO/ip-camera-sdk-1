package main.java.com.netdevsdk.demo.vca.face;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.Window;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.util.stream.Collectors;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.sun.jna.Pointer;
import com.sun.jna.ptr.IntByReference;

import main.java.com.netdevsdk.demo.NetDemo;
import main.java.com.netdevsdk.lib.NetDEVSDKLib;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_ID_LIST_S;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_LIB_INFO_S;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_PERSONLIB_SYNC_INFO_S;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_PERSON_LIB_CAP_LIST_S;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;

public class SyncPersonLibWindow extends JDialog{
    
    private Pointer lpUserId;
    JPanel  PersonLibWindowPanel = new JPanel();

    
    public SyncPersonLibWindow(Pointer lpUserID) {
        this.lpUserId = lpUserID;
        this.setSize(429,299);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        this.setTitle("Synchronize");
        this.setVisible(true);
        
        Toolkit toolkit=Toolkit.getDefaultToolkit();
        Dimension screenSize =toolkit.getScreenSize();
        int x=(screenSize.width-this.getWidth())/2;
        int y=(screenSize.height-this.getHeight())/2;
        this.setLocation(x,y);
        getContentPane().add(PersonLibWindowPanel, BorderLayout.CENTER);
        PersonLibWindowPanel.setLayout(null);
        
        JScrollPane SyncDeviceScrollPane = new JScrollPane();
        SyncDeviceScrollPane.setBounds(10, 10, 393, 207);
        PersonLibWindowPanel.add(SyncDeviceScrollPane);
        
        NetDemo.SyncLibToDeviceTable = new JTable(NetDemo.SyncDeviceModel) {
            public boolean isCellEditable(int row,int column) {
                return false;
            }
        };
        SyncDeviceScrollPane.setViewportView(NetDemo.SyncLibToDeviceTable);
        
        JButton jButtonSync = new JButton("Synchornize");
        jButtonSync.setBounds(59, 227, 110, 23);
        PersonLibWindowPanel.add(jButtonSync);
        
        JButton jButtonCancle = new JButton("Cancle");
        jButtonCancle.setBounds(235, 227, 110, 23);
        PersonLibWindowPanel.add(jButtonCancle);
        
        /* Get device ID */
        NetDemo.SyncLibToDeviceTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = NetDemo.SyncLibToDeviceTable.rowAtPoint(e.getPoint());
                NetDemo.deviceID = Integer.parseInt(NetDemo.SyncLibToDeviceTable.getValueAt(row, 0).toString());
                }
            });
        
        jButtonCancle.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        
        jButtonSync.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                NETDEV_LIB_INFO_S stPersonLibInfo = NetDemo.mapPersonLib.get(NetDemo.jComboBoxPersonLib.getItemAt(NetDemo.jComboBoxPersonLib.getSelectedIndex()));
                NETDEV_ID_LIST_S stDeviceIDList = new NETDEV_ID_LIST_S();
                stDeviceIDList.udwNum = 1;
                stDeviceIDList.pudwIDs = new IntByReference(NetDemo.deviceID);
                /* 将指定人脸库同步至设备 返回成功表示接口下发参数成功
                 * 获取同步信息需调用NETDEV_FindPersonLibSyncInfoList、NETDEV_FindNextPersonLibSyncInfo、NETDEV_FindClosePersonLibSyncInfoList */
                boolean bRet = NetDemo.netdevsdk.NETDEV_SyncPersonLibToDevice(lpUserID, stPersonLibInfo.udwID, stDeviceIDList);
                if (bRet) {
                    JOptionPane.showMessageDialog(null, "NETDEV_SyncPersonLibToDevice success");
                    
                } else {
                    JOptionPane.showMessageDialog(null, "NETDEV_SyncPersonLibToDevice failed: "+NetDemo.netdevsdk.NETDEV_GetLastError());
                    return;
                }
            }
        });
        

    }
}
