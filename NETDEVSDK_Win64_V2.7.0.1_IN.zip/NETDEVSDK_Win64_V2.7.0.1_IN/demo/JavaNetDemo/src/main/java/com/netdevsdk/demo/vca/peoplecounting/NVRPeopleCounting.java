package main.java.com.netdevsdk.demo.vca.peoplecounting;

import java.util.Vector;

import javax.swing.JOptionPane;

import com.sun.jna.Memory;
import com.sun.jna.Pointer;
import com.sun.jna.ptr.IntByReference;

import main.java.com.netdevsdk.demo.NetDemo;
import main.java.com.netdevsdk.demo.util.Common;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_LAPI_SUB_INFO_S;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_MULTI_TRAFFIC_STATISTICS_COND_S;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_OPERATE_LIST_S;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_STRUCT_IMAGE_INFO_S;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_SUBSCRIBE_SUCC_INFO_S;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_TRAFFIC_STATISTICS_INFO_S;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_TRAFFIC_STATISTICS_TYPE_E;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_USER_SIMPLE_INFO_S;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_CROWD_DENSITY_GROUP_INFO_S;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_CROWD_DENSITY_RULE_INFO_S;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_CROWD_DENSITY_STATISTIC_TYPE_E;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_DEV_BASIC_INFO_S;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_FACE_STRUCT_INFO_S;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_IPADDR_INFO_S;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_CHANNEL_RULE_INFO_S;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_CROWD_DENSITY_RULE_INFO_S;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_ALARM_RULE_INFO_S;



/**
 * @description NVR/VMS data report and find data records.
 * @introduction Support NVR/VMS. 
 */
public class NVRPeopleCounting {
    /**
     * @description To start NVR/VMS data report.
     * @introduction It is mainly realized by the CountThread.execute.
     */
    public static void startRealTime() {
        if(null == NetDemo.lpUserID)
        {
            JOptionPane.showMessageDialog(null, "Please Login device first. error code"+NetDemo.netdevsdk.NETDEV_GetLastError());
            return;
        }
        if(NetDemo.ChannelID == 0)
        {
            JOptionPane.showMessageDialog(null, "Please select an online channel after login.");
            return;
        }
        NetDemo.flag=true;
        NetDemo.CountThread.execute(NetDemo.t);
    }
    /**
     * @description To stop NVR/VMS data report
     * @introduction Calling the interface of NETDEV_StopTrafficStatistic.
     */
    public static void stopRealTime() {
        if(null == NetDemo.lpUserID)
        {
            JOptionPane.showMessageDialog(null, "Please Login device first. error code"+NetDemo.netdevsdk.NETDEV_GetLastError());
            return;
        }   
        NetDemo.flag=false;
        int searchId=0;
        try {
            searchId = NetDemo.udwSearchID.getValue();
        }catch(Exception t) {
            return;
        }
        boolean rBet = NetDemo.netdevsdk.NETDEV_StopTrafficStatistic(NetDemo.lpUserID,searchId);
        if(rBet) 
        {
            JOptionPane.showMessageDialog(null, "Stop success");
            NetDemo.t.run();
            NetDemo.udwSearchID=null;
        }
        else 
        {
            JOptionPane.showMessageDialog(null, "StopTrafficStatistic failed,error code"+NetDemo.netdevsdk.NETDEV_GetLastError());
            System.out.printf("NETDEV_StopTrafficStatistic failed:%d\n", NetDemo.netdevsdk.NETDEV_GetLastError());
            return;
        }
    }
    /**
     * @description To find  data records.
     * @introduction  Calling the interface of NETDEV_StartMultiTrafficStatistic,NETDEV_GetTrafficStatisticProgress,NETDEV_FindTrafficStatisticInfoList,NETDEV_FindCloseTrafficStatisticInfo.
     */
    public static void dataStatistics() {
        if(null == NetDemo.lpUserID)
        {
            JOptionPane.showMessageDialog(null, "Please Login device first. error code"+ NetDemo.netdevsdk.NETDEV_GetLastError());
            return;
        }

        if(NetDemo.ChannelID == 0){
            JOptionPane.showMessageDialog(null, "Please select an online channel after login.");
            return;
        }

        NetDemo.PeopleCountingVMSNVRStatistalTableModel.setRowCount(0);
        boolean bRet = false;
        NETDEV_MULTI_TRAFFIC_STATISTICS_COND_S stStatisticCond = new NETDEV_MULTI_TRAFFIC_STATISTICS_COND_S();
        stStatisticCond.stChannelIDs = new NETDEV_OPERATE_LIST_S();
        stStatisticCond.stChannelIDs.pstOperateInfo = new Memory(4);
        stStatisticCond.stChannelIDs.pstOperateInfo.setInt(0, NetDemo.ChannelID);
        stStatisticCond.stChannelIDs.dwSize = 1;
        stStatisticCond.udwFormType =  NetDemo.jComboBoxPeopleCountingVMSNVRStatisticalReportType.getSelectedIndex();
        stStatisticCond.udwStatisticsType = NETDEV_TRAFFIC_STATISTICS_TYPE_E.NETDEV_TRAFFIC_STATISTICS_TYPE_ALL;
        String getCountingVMSNVRStatisticsBeginTime =  NetDemo.CountingVMSNVRStatisticsBeginTime.getText();
        long get1=Common.date2TimeStamp(getCountingVMSNVRStatisticsBeginTime.toString(),  NetDemo.DateFormat);
        String getCountingVMSNVRStattisticsEndTime =  NetDemo.CountingVMSNVRStattisticsEndTime.getText();
        long get2=Common.date2TimeStamp(getCountingVMSNVRStattisticsEndTime.toString(),  NetDemo.DateFormat);
        if(get1>get2) 
        {
            JOptionPane.showMessageDialog(null, "Start time can not more than end time");
            return;
        }
        stStatisticCond.tBeginTime = get1;
        stStatisticCond.tEndTime = get2;
        IntByReference udwSearchID = new IntByReference();
        bRet =  NetDemo.netdevsdk.NETDEV_StartMultiTrafficStatistic( NetDemo.lpUserID, stStatisticCond, udwSearchID);
        if(false == bRet)
        {
            JOptionPane.showMessageDialog(null, "StartMultiTrafficStatistic failed error code"+ NetDemo.netdevsdk.NETDEV_GetLastError());
            System.out.printf("NETDEV_StartMultiTrafficStatistic failed:%d\n",  NetDemo.netdevsdk.NETDEV_GetLastError());
            return;
        }
        int count=0;
        /*查询统计进度 Query statistics progress */
        while(true)
        {
            IntByReference dwProgress = new IntByReference();
            bRet =  NetDemo.netdevsdk.NETDEV_GetTrafficStatisticProgress( NetDemo.lpUserID, udwSearchID.getValue(), dwProgress);
            count++;
            if(count==100) 
            {
                JOptionPane.showMessageDialog(null, "Wait more than 100s,data is to large,please reinput time");
                return;
            }
            if(dwProgress.getValue() == 100)
            {
                break;
            }
            else
            {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }
        Pointer lpStaticHandle = NetDemo.netdevsdk.NETDEV_FindTrafficStatisticInfoList(NetDemo.lpUserID, udwSearchID.getValue());
        if(lpStaticHandle != null)
        {
            while(true)
            {
                NETDEV_TRAFFIC_STATISTICS_INFO_S stStatisticInfo = new NETDEV_TRAFFIC_STATISTICS_INFO_S();
                bRet = NetDemo.netdevsdk.NETDEV_FindNextTrafficStatisticInfo(lpStaticHandle, stStatisticInfo);
                System.out.println("1");
                if(bRet != true)
                {
                    break;
                }
                else
                {
                    for(int i = 0; i < stStatisticInfo.udwSize; i++)
                    {
                        Vector<String> StatisticInfoVector = new Vector<String>();

                        StatisticInfoVector.add(String.valueOf(stStatisticInfo.dwChannelID));
                        StatisticInfoVector.add(String.valueOf(i));
                        StatisticInfoVector.add(String.valueOf(stStatisticInfo.audwEnterCount[i]));
                        StatisticInfoVector.add(String.valueOf(stStatisticInfo.audwExitCount[i]));
                        NetDemo.PeopleCountingVMSNVRStatistalTableModel.addRow(StatisticInfoVector);
                    }
                }
            }
            bRet =  NetDemo.netdevsdk.NETDEV_FindCloseTrafficStatisticInfo(lpStaticHandle);
            if(false == bRet)
            {
                System.out.printf("NETDEV_FindCloseTrafficStatisticInfo failed:%d\n",  NetDemo.netdevsdk.NETDEV_GetLastError());
                return;
            }
        }
    
    }
    
    public static void registerPeopleCountAlarm() {
        if(null == NetDemo.lpUserID)
        {
            JOptionPane.showMessageDialog(null, "Please Login device first. error code"+NetDemo.netdevsdk.NETDEV_GetLastError());
            return;
        }
        
        if(-1 != NetDemo.udwPeopleCountAlarmSubID)
        {
            JOptionPane.showMessageDialog(null, "Please UnSubLapiAlarm first.");
            return;
        }
        
        NETDEV_LAPI_SUB_INFO_S stSubInfo = new NETDEV_LAPI_SUB_INFO_S();
        stSubInfo.udwType  = 16384; //bit14 16384
        NETDEV_SUBSCRIBE_SUCC_INFO_S stSubSuccInfo = new NETDEV_SUBSCRIBE_SUCC_INFO_S();
         
        boolean bRet = NetDemo.netdevsdk.NETDEV_SubscibeLapiAlarm(NetDemo.lpUserID, stSubInfo, stSubSuccInfo);
        if(false == bRet){
        	System.out.printf("NETDEV_SubscibeLapiAlarm failed:%d\n", NetDemo.netdevsdk.NETDEV_GetLastError());
        	JOptionPane.showMessageDialog(null, "NETDEV_SubscibeLapiAlarm failed");
        	return;
        }
        else{
        	NetDemo.udwPeopleCountAlarmSubID = stSubSuccInfo.udwID;
        	bRet =  NetDemo.netdevsdk.NETDEV_SetPeopleCountAlarmCallBack(NetDemo.lpUserID, NetDemo.peopleAlarmMessCB, NetDemo.lpUserID);
            if(false == bRet)
            {
                JOptionPane.showMessageDialog(null, "NETDEV_SetPeopleCountAlarmCallBack failed,error code"+NetDemo.netdevsdk.NETDEV_GetLastError());
                System.out.printf("NETDEV_SetPeopleCountAlarmCallBack failed:%d", NetDemo.netdevsdk.NETDEV_GetLastError());
                return;
            }
            
            JOptionPane.showMessageDialog(null, "NETDEV_SubscibeLapiAlarm success");
        }        
      
    }
    
    public static void unRegisterPeopleCountAlarm() {
        if(null == NetDemo.lpUserID)
        {
            JOptionPane.showMessageDialog(null, "Please Login device first. error code"+NetDemo.netdevsdk.NETDEV_GetLastError());
            return;
        }
        
        
        boolean bRet = NetDemo.netdevsdk.NETDEV_UnSubLapiAlarm(NetDemo.lpUserID, NetDemo.udwPeopleCountAlarmSubID);
        if(false == bRet){
            System.out.printf("NETDEV_UnSubLapiAlarm failed:%d\n", NetDemo.netdevsdk.NETDEV_GetLastError());
            JOptionPane.showMessageDialog(null, "NETDEV_UnSubLapiAlarm failed");
            return;
        }
        else
        {
            NetDemo.udwPeopleCountAlarmSubID = -1;
            NetDemo.textField_SrcID.setText(null);
			NetDemo.textField_SrcName.setText(null);
			NetDemo.textField_TotalIn.setText(null);
			NetDemo.textField_TotalOut.setText(null);
			
			NetDemo.textField_AlarmType.setText(null);
			NetDemo.textField_TimeStamp.setText(null);
			NetDemo.textField_AlarmSeq.setText(null);
			NetDemo.textField_GroupID.setText(null);
			NetDemo.textField_CrowObjectIn.setText(null);
			NetDemo.textField_CrowObjectOut.setText(null);
			
            JOptionPane.showMessageDialog(null, "NETDEV_UnSubLapiAlarm success");
            return;
        }
    }
    
    public static void addGroup() {
    	 if(null == NetDemo.lpUserID)
         {
             JOptionPane.showMessageDialog(null, "Please Login device first. error code"+NetDemo.netdevsdk.NETDEV_GetLastError());
             return;
         }
    	 
    	 if(NetDemo.ChannelID == 0) {
 			JOptionPane.showMessageDialog(null, "Please select an online channel after login.");
 			return;
 		}
    	 
    	 
	    IntByReference pUdwGroupID = new IntByReference();
	    NETDEV_CROWD_DENSITY_GROUP_INFO_S stCrowdDensityGroupInfo = new NETDEV_CROWD_DENSITY_GROUP_INFO_S();
	    stCrowdDensityGroupInfo.udwChannelRuleNum = 1;
	    NETDEV_CHANNEL_RULE_INFO_S stChannelRuleInfoList = new NETDEV_CHANNEL_RULE_INFO_S();
	    
	    stChannelRuleInfoList.udwChannelID = NetDemo.ChannelID;
	    System.out.printf("NETDEV_AddCrowdDensityGroupInfo udwChannelID:%d\n", stChannelRuleInfoList.udwChannelID);
	    stChannelRuleInfoList.udwRuleNum = 0;
	    stChannelRuleInfoList.write();
	    stCrowdDensityGroupInfo.pstChannelRuleInfoList = stChannelRuleInfoList.getPointer();
	   
	    stCrowdDensityGroupInfo.stCrowdDensityRuleInfo = new NETDEV_CROWD_DENSITY_RULE_INFO_S();
	    stCrowdDensityGroupInfo.stCrowdDensityRuleInfo.stCriticalAlarmRuleInfo = new NETDEV_ALARM_RULE_INFO_S();
	    stCrowdDensityGroupInfo.udwGroupID  = -1;
	    Common.stringToByteArray(NetDemo.textField_GroupName.getText(), stCrowdDensityGroupInfo.szGroupName);
	    
	  
	    if(0 == NetDemo.comboBox_StatisticalType.getSelectedIndex()) {
	    	stCrowdDensityGroupInfo.udwStatisticalType = 1;
		}else if( 1 == NetDemo.comboBox_StatisticalType.getSelectedIndex()) {
			stCrowdDensityGroupInfo.udwStatisticalType = 2;
		}
	    
	    
	    stCrowdDensityGroupInfo.udwReportInterval = 5;
	    stCrowdDensityGroupInfo.stCrowdDensityRuleInfo.stCriticalAlarmRuleInfo.bEnabled = 1;
	    stCrowdDensityGroupInfo.stCrowdDensityRuleInfo.stCriticalAlarmRuleInfo.udwAlarmThermal = 1;
	    stCrowdDensityGroupInfo.write();
	    boolean bRet = NetDemo.netdevsdk.NETDEV_AddCrowdDensityGroupInfo(NetDemo.lpUserID, stCrowdDensityGroupInfo, pUdwGroupID);
        if(false == bRet){
            System.out.printf("NETDEV_AddCrowdDensityGroupInfo failed:%d\n", NetDemo.netdevsdk.NETDEV_GetLastError());
            JOptionPane.showMessageDialog(null, "NETDEV_AddCrowdDensityGroupInfo failed"+NetDemo.netdevsdk.NETDEV_GetLastError());
            return;
        }
        else
        {
        	NetDemo.GroupInfo[NetDemo.GroupIndex] = pUdwGroupID.getValue();
        	System.out.printf("iiii:%d,%d\n", NetDemo.GroupIndex,NetDemo.GroupInfo[NetDemo.GroupIndex]);
        	NetDemo.GroupIndex++;
        	JOptionPane.showMessageDialog(null, "NETDEV_AddCrowdDensityGroupInfo success");
            return;
        }
        
    }
    
    public static void deleteGroup() {
    	
    	 if(null == NetDemo.lpUserID)
         {
             JOptionPane.showMessageDialog(null, "Please Login device first. error code"+NetDemo.netdevsdk.NETDEV_GetLastError());
             return;
         }
    	 
    	 Pointer lpFindHandle = NetDemo.netdevsdk.NETDEV_FindCrowdDensityGroupList(NetDemo.lpUserID);
         if(null == lpFindHandle) {
             System.out.printf("NETDEV_FindCrowdDensityGroupList failed: "+ NetDemo.netdevsdk.NETDEV_GetLastError());
             JOptionPane.showMessageDialog(null, "NETDEV_FindCrowdDensityGroupList failed"+NetDemo.netdevsdk.NETDEV_GetLastError());
             return;
         }
         
         if(lpFindHandle != null)
         {
             while(true)
             {
            	 NETDEV_CROWD_DENSITY_GROUP_INFO_S stCrowdDensityGroupInfo = new NETDEV_CROWD_DENSITY_GROUP_INFO_S();
                 stCrowdDensityGroupInfo.udwChannelRuleNum = 1;
  	             NETDEV_CHANNEL_RULE_INFO_S stChannelRuleInfoList = new NETDEV_CHANNEL_RULE_INFO_S();  	    
  	             stCrowdDensityGroupInfo.pstChannelRuleInfoList = stChannelRuleInfoList.getPointer();
            	 boolean bRet = NetDemo.netdevsdk.NETDEV_FindNextCrowdDensityGroupInfo(lpFindHandle, stCrowdDensityGroupInfo);
                 if(true == bRet)
                 {
                	 stCrowdDensityGroupInfo.read();             
                	 bRet = NetDemo.netdevsdk.NETDEV_DeleteCrowdDensityGroupInfo(NetDemo.lpUserID, stCrowdDensityGroupInfo.udwGroupID);
        	         if(false == bRet){
        	            System.out.printf("NETDEV_DeleteCrowdDensityGroupInfo failed:%d\n", NetDemo.netdevsdk.NETDEV_GetLastError());
        	            JOptionPane.showMessageDialog(null, "NETDEV_DeleteCrowdDensityGroupInfo failed"+NetDemo.netdevsdk.NETDEV_GetLastError());
        	            return;
        	         }
        	         else
        	         {
        	        	 JOptionPane.showMessageDialog(null, "Delete DensityGroupID:"+stCrowdDensityGroupInfo.udwGroupID + " is success");		        
        	         }                  	 	         
                 }
                 else
                 {
                     break;
                 }
             }
        }        
        NetDemo.netdevsdk.NETDEV_FindCloseCrowdDensityGroupList(lpFindHandle);
        NetDemo.textField_GroupName.setText(null);
    }
    
}
