#pragma once


// CCfgAttrCollect 

class CCfgAttrCollect : public CDialog
{
    DECLARE_DYNAMIC(CCfgAttrCollect)

public:
    CCfgAttrCollect(CWnd* pParent = NULL);
    virtual ~CCfgAttrCollect();

    enum { IDD = IDD_CFG_ATTRCOLLECT };
    void ReadGlobeToAttrCollect();

protected:
    virtual void DoDataExchange(CDataExchange* pDX); 
    virtual BOOL OnInitDialog();
    DECLARE_MESSAGE_MAP()

    void getAttrCollectCfg();

private:

    NETDEV_ATTR_COLLECT_INFO_S m_stAttrCollectInfo;
public:

    afx_msg void OnBnClickedSaveAttrcollect();
    afx_msg void OnBnClickedRefreshAttrcollect();
};
