#pragma once
#include "afxwin.h"

class CDlgAddDeviceChn : public CDialog
{
    DECLARE_DYNAMIC(CDlgAddDeviceChn)

public:
    CDlgAddDeviceChn(CWnd* pParent = NULL);
    CDlgAddDeviceChn(INT32 dwChnID,CWnd* pParent = NULL);
    virtual ~CDlgAddDeviceChn();

    enum { IDD = ID_MENU_DEVICEOPER_ADDCHN };

protected:
    virtual void DoDataExchange(CDataExchange* pDX);
    virtual BOOL OnInitDialog();
    DECLARE_MESSAGE_MAP()

private:
    void InitCombo();

public:
    CString m_strIP;
    INT32 m_dwPort;
    INT32 m_dwChnID;
    CString m_strUsername;
    CString m_strPassword;

public:
    afx_msg void OnBnClickedGetDeviceChn();
    afx_msg void OnBnClickedModifyDeviceChn();
    afx_msg void OnBnClickedAddDeviceChn();
    afx_msg void OnBnClickedSelectPro();
    afx_msg void OnBnClickedCancel();
    CComboBox m_oAddType;
    INT32 m_udwAddType;

    CComboBox m_oAddIPAddrType;
    INT32 m_udwAddIPAddrType;

    CComboBox m_oAddAccessPro;
    INT32 m_udwAddAccessPro;
    INT32 m_udwAddAccessCustomPro;

    CComboBox m_oAddPtz;
    INT32 m_udwAddPtz;

    INT32 m_udwAddedChnNum;
    afx_msg void OnCbnSelchangeComboAddDeviceChnAccessproType();
};
