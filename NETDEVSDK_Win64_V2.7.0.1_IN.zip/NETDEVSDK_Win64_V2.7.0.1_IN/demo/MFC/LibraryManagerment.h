#pragma once
#include "afxcmn.h"
#include "PersonInfo.h"
#include "VehicleInfo.h"


// CLibraryManagerment �Ի���

class CLibraryManagerment : public CDialog
{
	DECLARE_DYNAMIC(CLibraryManagerment)

public:
	CLibraryManagerment(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CLibraryManagerment();

// �Ի�������
	enum { IDD = IDD_FACE_LIBRARY_MANAGERMENT };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

private:
	void InitCtrl();

public:
	void SetType(INT32 nType);
    VOID FindPersonLibInfo();
    VOID FindVehicleLibInfo();
    VOID FindPersonInfo();
    VOID FindVehicleInfo();
    VOID EnumNETDEV_PLATE_COLOR_EConventToString(int dwEnum, std::string& strColor);
    VOID EnumNETDEV_PLATE_TYPE_EConventToString(int dwEnum, std::string& strType);
    VOID SyncPersonLibToDevice();
private:
	CListCtrl m_oInfoList;
	INT32 m_nType; //0:��ʾ������1����ʾ����
	CPersonInfo   m_oDlgPersonInfo;
	CVehicleInfo m_oDlgVehicleInfo;
   

    CString m_strLibName;
    std::vector<NETDEV_LIB_INFO_S> m_oLibInfoVector;
    std::vector<NETDEV_PERSON_INFO_S> m_oPersomInfoVector;
    std::vector<NETDEV_VEHICLE_DETAIL_INFO_S> m_oVehicleInfoVector;
    
    CComboBox m_oCBoxLibName;

public:
	afx_msg void OnBnClickedBtnAddPersonInfo();
    afx_msg void OnBnClickedBtnAddVehicleInfo();
    afx_msg void OnBnClickedBtnGetPersonLibList();
    afx_msg void OnBnClickedBtnDelPersonLib();
    afx_msg void OnBnClickedBtnGetPersonInfo();
    afx_msg void OnLvnItemchangedListPersonInfoList(NMHDR *pNMHDR, LRESULT *pResult);
    afx_msg void OnBnClickedBtnDeletePersonInfo();
    afx_msg void OnBnClickedBtnModefyPersonInfo();
    afx_msg void OnBnClickedBtnSyncPersonLibToDevice();
};
