#pragma once

class CMenuMaintain : public CDialog
{
    DECLARE_DYNAMIC(CMenuMaintain)

public:
    CMenuMaintain(CWnd* pParent = NULL);
    virtual ~CMenuMaintain();

    enum { IDD = IDD_MENU_MAINTAIN };

protected:
    virtual void DoDataExchange(CDataExchange* pDX);
    DECLARE_MESSAGE_MAP()
public:
    afx_msg void OnBnClickedReboot();
    afx_msg void OnBnClickedFactoryDefault();
    afx_msg void OnBnClickedButtonStartRecord();
    afx_msg void OnBnClickedButtonStopRecord();
    CEdit m_oConfigFile;
    afx_msg void OnBnClickedButtonBrowseConfigFile();
    afx_msg void OnBnClickedButtonExportConfigFile();
    afx_msg CString GetCurrentPath();
    afx_msg void OnBnClickedButtonImportConfigFile();
    CString m_strConfigFilePath;
    CString m_strLocalUpgradeFilePath;
    afx_msg void OnBnClickedButtonBrowseLocalUpgradeFile();
    CEdit m_oLocalUpgradeFile;
    afx_msg void OnBnClickedButtonLocalUpgrade();
    afx_msg void OnBnClickedButtonCheckNewVersion();
    afx_msg void OnBnClickedButtonGetUpgradeStatus();
    CProgressCtrl m_oUpgradeProgress;
    CString m_strUpgradeStatus;
};
