#pragma once


// CPersonMonitor �Ի���

class CPersonMonitor : public CDialog
{
	DECLARE_DYNAMIC(CPersonMonitor)

public:
	CPersonMonitor(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPersonMonitor();
    VOID SetType(INT32 dwType);
    VOID FindPersonLibInfo();
    VOID SetMontiorInfo(LPNETDEV_MONITION_INFO_S pstMotitorVector);
    VOID ReloadMontiorInfo();
    VOID CleanDialogCache();

// �Ի�������
	enum { IDD = IDD_DLG_PERSON_MONITOR };

private:
    VOID AddPersonMonitor();
    VOID ModifyPersonMonitor();

    INT32 m_nType; //0:��ʾ���ӣ�1����ʾ�޸�
    std::vector<NETDEV_LIB_INFO_S> m_oLibInfoVector;
    LPNETDEV_MONITION_INFO_S m_pstMotitorVector;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

    CString m_strTaskName;
    INT32 m_dwMonitorType;
    CString m_strDescribe;
    INT32 m_dwMonitorObject;
    CComboBox m_oCBoxLibName;

	DECLARE_MESSAGE_MAP()
public:
    afx_msg void OnBnClickedBtnAddPersonMonitor();
};
