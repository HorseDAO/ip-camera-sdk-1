#pragma once
#include "afxcmn.h"

// CProduceSafe �Ի���

class CProduceSafe : public CDialog
{
	DECLARE_DYNAMIC(CProduceSafe)

public:
	CProduceSafe(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CProduceSafe();

// �Ի�������
	enum { IDD = IDD_VCA_PRODUCE_SAFE };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
     virtual BOOL OnInitDialog();
	DECLARE_MESSAGE_MAP()
public:
    afx_msg void OnBnClickedButton1();
    INT32 m_dwSubID;
    afx_msg void OnBnClickedButton2();

    //UINT m_udwAlarmType;
    ULONGLONG tAlarmTime;
    UINT m_udwSeq;
    CString m_strDeviceID;
    CString m_strRelatedID;
    CString m_strSourceName;
    CString m_strAlarmType;
};
