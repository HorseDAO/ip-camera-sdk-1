#pragma once


// CVehicleInfo �Ի���

class CVehicleInfo : public CDialog
{
	DECLARE_DYNAMIC(CVehicleInfo)

public:
	CVehicleInfo(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CVehicleInfo();
    virtual BOOL OnInitDialog();

// �Ի�������
	enum { IDD = IDD_DLG_VEHICLE_INFO };

    VOID InitDialog();
    VOID SetType(INT32 dwType);
    VOID SetVehicleLibID(INT32 dwLibID);
    VOID AddVehicleInfo();
    VOID ModifyVehicleInfo();
    VOID SetVehicleInfo(LPNETDEV_VEHICLE_DETAIL_INFO_S pstVehicleDetailInfo);
    VOID ReloadVehicleInfo();
    VOID CleanCacheData();

private:
    CString     m_strLicensePlate;
    CComboBox   m_oCBoxLicensePlateType;
    CComboBox   m_oCBoxLicensePlateColor;
    CComboBox   m_oCBoxCarColor;

    INT32 m_nType; //0:��ʾ���ӣ�1����ʾ�޸�
    INT32 m_dwVehicleLibID;
    LPNETDEV_VEHICLE_DETAIL_INFO_S m_pstVehicleDetailInfo;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
    afx_msg void OnBnClickedBtnAddVehicleInfo();
};
