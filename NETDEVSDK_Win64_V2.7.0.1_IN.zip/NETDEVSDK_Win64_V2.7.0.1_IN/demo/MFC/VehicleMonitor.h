#pragma once


// CVehicleMonitor �Ի���

class CVehicleMonitor : public CDialog
{
	DECLARE_DYNAMIC(CVehicleMonitor)

public:
	CVehicleMonitor(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CVehicleMonitor();

    VOID SetType(INT32 dwType);
    VOID SetMonitorInfo(LPNETDEV_MONITION_INFO_S pstMotitorInfo);
    VOID ReloadMontiorInfo();
    VOID InitDialog();
    VOID AddVehicleMonitor();
    VOID ModifyVehicleMonitor();
    VOID FindVehicleLibInfo();
    VOID CleanCache();

// �Ի�������
	enum { IDD = IDD_DLG_VEHICLE_MONITOR };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()

private:
     CString m_strTaskName;
     INT32 m_dwMonitorType;
     CComboBox m_oCBoxMonitorReason;
     CString m_strDescribe;
     CComboBox m_oCBoxLibName;

     INT32 m_nType; //0:��ʾ���ӣ�1����ʾ�޸�
     std::vector<NETDEV_LIB_INFO_S> m_oLibInfoVector;
     LPNETDEV_MONITION_INFO_S m_pstMotitorInfo;

public:
    afx_msg void OnBnClickedBtnAddVehicleMonitor();
};
