#pragma once


// CVehiclePassRecord �Ի���

class CVehiclePassRecord : public CDialog
{
	DECLARE_DYNAMIC(CVehiclePassRecord)

public:
	CVehiclePassRecord(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CVehiclePassRecord();

// �Ի�������
	enum { IDD = IDD_VEHICLE_PASS_RECORD };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
    virtual BOOL OnInitDialog();

    VOID InitPlateColor();
    VOID InitCarColor();
    BOOL getTimeInfo(INT64& dwBeginTime, INT64& dwEndTime);
    long GetTick(const CString& strTime);
    VOID SavePicture(CString pszFileName, CHAR *pszBuf, INT32 dwSize);
    VOID InitVehiclePassList();
    VOID FindVehicleAlarmInfo();
    VOID CleanVehicleRecordInfoVector();
    VOID DisPlayVehicleRecordInfoVector();
    CString EnumNETDEV_PLATE_COLOR_EConventToString(INT32 dwEnum);
    CString EnumNETDEV_PLATE_TYPE_EConventToString(INT32 dwEnum);
    CString EnumNETDEV_VEHICLE_TYPE_EConventToString(INT32 dwEnum);
    CString EnumNETDEV_VEHICLE_MONITOR_TYPE_EConventToString(INT32 dwEnum);

private:
    CDateTimeCtrl m_oBeginDate;
    CDateTimeCtrl m_oBeginTime;
    CDateTimeCtrl m_oEndDate;
    CDateTimeCtrl m_oEndTime;
    CString m_strBayonetName;
    CString m_strPlateNumber;
    CComboBox m_oCBoxPlateColor;
    CComboBox m_oCBoxCarColor;
    CListCtrl m_oVehiclePassList;
    CString m_strTotalNumber;
    CString m_strCurrentNumber;

    INT32 m_dwTotalNumber;
    INT32 m_dwCurrentNumber;
    std::vector<NETDEV_VEHICLE_RECORD_INFO_S> m_oVehicleRecordInfoVector;

	DECLARE_MESSAGE_MAP()
public:
    afx_msg void OnBnClickedButtonVehiclePassFind();
    afx_msg void OnBnClickedButtonVehiclePassPrev();
    afx_msg void OnBnClickedButtonVehiclePassNext();
};
